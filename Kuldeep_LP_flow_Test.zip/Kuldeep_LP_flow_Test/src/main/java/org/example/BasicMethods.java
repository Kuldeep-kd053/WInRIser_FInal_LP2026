package org.example;

import io.appium.java_client.windows.WindowsDriver;
import io.appium.java_client.windows.WindowsElement;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.util.Units;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.*;
import org.json.JSONObject;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.*;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;


public class BasicMethods {
    static String licenseKey = "";
    private static XWPFDocument document = null;
    private static final String docPath = System.getProperty("user.home") + "\\Downloads\\PageDetails.docx";
    private static int count = 1; // For tracking calls and sequence
    private static XWPFDocument doc = new XWPFDocument();
    static ArrayList<String> tabs;
    static XWPFRun run;
    static String fileName = "wrsetup.exe";  // Change if needed
    static String downloadDir = System.getProperty("user.home") + "\\Downloads";
    static String filePath = downloadDir + "\\" + fileName;
    static String LP_URL = "https://winriser.com";
    static String ip = "";
    static String modifiedIP = "";
    public static String username;
    public static String password;
    static WindowsDriver<WindowsElement> appDriver;
    private static Process debugChromeProcess;
    public static WebDriver browserDriver;

    public static void launchDebugChrome() throws IOException, InterruptedException {
        if (debugChromeProcess != null && debugChromeProcess.isAlive()) {
            System.out.println("Debug Chrome already running.");
            return;
        }

        String wrapperPath = "C://Tools//ChromeWrapper//Chromewrapper.exe"; // your wrapper exe
        ProcessBuilder pb = new ProcessBuilder(wrapperPath);
        debugChromeProcess = pb.start();
        Thread.sleep(2000); // let Chrome fully start
        System.out.println("Debug Chrome launched via wrapper.");

    }

    public static void attachToDebugChrome() {
        if (browserDriver != null) {
            System.out.println("WebDriver already attached.");
            return;
        }
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.setExperimentalOption("debuggerAddress", "127.0.0.1:9222");
        browserDriver = new ChromeDriver(options);
        System.out.println("Attached to debug Chrome.");
    }

    public static void clickOnDownloadButton() {
        browserDriver.findElement(By.xpath("//a[contains(text(),'Download Now')]")).click();
    }

    public static void launchBrowserIfNeeded() throws IOException, InterruptedException {
        launchDebugChrome();
        attachToDebugChrome();
    }

    public static void closeBrowser() throws InterruptedException, IOException {
        Thread.sleep(600);


        // Close debug browser: case 1 (launched via Java)
        if (debugChromeProcess != null && debugChromeProcess.isAlive()) {
            debugChromeProcess.destroy();
            System.out.println("Debug Chrome closed (via Java process handle).");
        } else {
            // Case 2: Debug Chrome launched by application (no handle available)
            System.out.println("Attempting to close Chrome running in debug mode...");

            // Run PowerShell to get Chrome processes with --remote-debugging-port
            Process findChrome = Runtime.getRuntime().exec(
                    "powershell -Command \"Get-CimInstance Win32_Process | " +
                            "Where-Object { $_.CommandLine -like '*--remote-debugging-port=9222*' } | " +
                            "ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
            );

            findChrome.waitFor();

            if (findChrome.exitValue() == 0) {
                System.out.println("Debug Chrome closed (via PowerShell taskkill).");
            } else {
                System.out.println("No debug Chrome found or could not be closed.");
            }
        }
    }


    public static void save_current_Page_URL(WebDriver browserDriver) {
        try {
            // Load existing doc or create new
            File file = new File(docPath);
            if (file.exists() && document == null) {
                FileInputStream fis = new FileInputStream(file);
                document = new XWPFDocument(fis);
                fis.close();
            } else if (document == null) {
                document = new XWPFDocument();
            }
            // Get URL
            String currentUrl = browserDriver.getCurrentUrl();
            //System.out.println("Capturing URL: " + currentUrl);
            // Add URL to doc
            XWPFParagraph para = document.createParagraph();
            run = para.createRun();
            run.setText("Step " + count + " URL: " + browserDriver.getTitle() + "\n" + currentUrl);
            run.addBreak(); // Line break
            run.addBreak(BreakType.PAGE); // Page break after each step
            save_doc();
            //System.out.println("Step " + count + " details saved to Word document.");
            count++; // increment step count
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void save_current_page_scrrentshot() {
        try {
            // Load existing doc or create new
            File file = new File(docPath);
            if (file.exists() && document == null) {
                FileInputStream fis = new FileInputStream(file);
                document = new XWPFDocument(fis);
                fis.close();
            } else if (document == null) {
                document = new XWPFDocument();
            }
            LocalDate today = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            String dateString = today.format(formatter);
            // Take Screenshot
            TakesScreenshot ts = (TakesScreenshot) browserDriver;
            File srcFile = ts.getScreenshotAs(OutputType.FILE);
            String imgPath = System.getProperty("user.home") + "\\Downloads\\PageDetails " + dateString + count + ".png";
            File destFile = new File(imgPath);
            org.openqa.selenium.io.FileHandler.copy(srcFile, destFile);
            // Add Screenshot to doc
            XWPFParagraph para = document.createParagraph();
            run = para.createRun();
            InputStream pic = new FileInputStream(imgPath);
            run.addPicture(pic, Document.PICTURE_TYPE_PNG, imgPath, Units.toEMU(400), Units.toEMU(300));
            pic.close();
            run.addBreak(BreakType.PAGE); // Page break after each step
            save_doc();
            count++; // increment step count

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void save_doc() throws IOException {
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String dateString = today.format(formatter);
        // Save doc
        String docPath = System.getProperty("user.home") + "\\Downloads\\PageDetails" + dateString + ".docx";
        FileOutputStream fos = new FileOutputStream(docPath);
        document.write(fos);
        fos.close();
    }

    public static void closeDocument() {
        try {
            if (document != null) {
                document.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void cross_sale() throws InterruptedException, IOException {
        browserDriver.navigate().refresh();
        Thread.sleep(6000);
        WebDriverWait wait = new WebDriverWait(browserDriver, 30);
        //one click
        System.out.println("oye jane wale");
        try {
            WebElement paymentIframe = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//iframe[@id='fsc-popup-frame']")));
            // Switch to the iframe
            System.out.println("oye kahi to jane wale");
            browserDriver.switchTo().frame(paymentIframe);
            browserDriver.findElement(By.xpath("//input[@name='card.number']")).sendKeys("4242424242424242");
            browserDriver.findElement(By.name("card.monthYear")).sendKeys("12");
            browserDriver.findElement(By.xpath("//input[@name='card.year']")).sendKeys("26");
            browserDriver.findElement(By.xpath("//input[@name='card.security']")).sendKeys("*RABE");
            save_current_page_scrrentshot();
            save_current_Page_URL(browserDriver);
            save_doc();
            try {
                WebElement compliance_checkbox = browserDriver.findElement(By.xpath("//input[@type='checkbox']"));
                compliance_checkbox.isDisplayed();
                compliance_checkbox.click();
            } catch (NoSuchElementException ignored) {
            }
            browserDriver.findElement(By.xpath("(//button[@type='submit'])[2]")).click();
        } catch (NoSuchElementException e) {
            browserDriver.findElement(By.xpath("(//button[@type='submit'])[2]")).click();
        }
    }

    public static void checkout_details() throws InterruptedException, IOException {
        Thread.sleep(3000);
        List<String> tabs = new ArrayList<>(browserDriver.getWindowHandles());
        String latestTab = tabs.get(tabs.size() - 1);
        browserDriver.switchTo().window(latestTab);
        System.out.println("Switched to latest tab: " + browserDriver.getCurrentUrl());
        save_current_Page_URL(browserDriver);
        save_doc();
        browserDriver.get(browserDriver.getCurrentUrl() + "&testmode=1");
        WebDriverWait wait = new WebDriverWait(browserDriver, 90);
        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("fsc-popup-frame")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(@class,'old-price')]")));
        // 6. Fill a payment form
        browserDriver.findElement(By.name("contact.email")).sendKeys("deeprandeepaq@tafmail.com");
        browserDriver.findElement(By.name("contact.firstName")).sendKeys("kuldeep");
        browserDriver.findElement(By.name("contact.lastName")).sendKeys("kumar");
        browserDriver.findElement(By.name("card.number")).sendKeys("4242424242424242");
        browserDriver.findElement(By.name("card.monthYear")).sendKeys("12");
        browserDriver.findElement(By.name("card.monthYear")).sendKeys("26");
        browserDriver.findElement(By.name("card.security")).sendKeys("*RABE");
        save_current_page_scrrentshot();
        save_doc();
        try {
            WebElement postal_code = browserDriver.findElement(By.name("contact.postalCode"));
            if (postal_code.isDisplayed()) {
                postal_code.sendKeys("95001");
            }
        } catch (NoSuchElementException ignored) {
        }
        try {
            WebElement complience_checkbox = browserDriver.findElement(By.id("compliance-checkbox"));
            complience_checkbox.isDisplayed();
            complience_checkbox.click();
        } catch (NoSuchElementException ignored) {
        }
        save_current_Page_URL(browserDriver);
        save_current_page_scrrentshot();
        save_doc();
        browserDriver.findElement(By.xpath("(//button[@type='submit'])[2]")).click();
        Thread.sleep(9000);

    }

    public static void fetch_licenseKey() throws IOException {
        // Scroll to bottom
        JavascriptExecutor js = (JavascriptExecutor) browserDriver;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
        WebDriverWait wait = new WebDriverWait(browserDriver, 5);
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[contains(text(),'License Information')])[1]")));
            WebElement licenseElement = browserDriver.findElement(By.xpath("//td[span[@tkey='Text14']]"));
            String text = licenseElement.getText();
            licenseKey = text.substring(text.indexOf(":") + 1).trim();
            System.out.println("License Key: " + licenseKey);
        } catch (Exception e) {
            try {
                wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//td[@style='text-align: right'])[1]")));
                licenseKey = browserDriver.findElement(By.xpath("(//td[@style='text-align: right'])[1]")).getText();
                System.out.println("License Key (second method): " + licenseKey);
            } catch (Exception ex) {
                System.out.println("License Key not found by either method.");
            }
        }
        save_current_Page_URL(browserDriver);
        save_doc();
        save_current_page_scrrentshot();
        save_doc();

    }

    public static void readCredentialsFromExcel() {
        String excelPath = "E:\\KDpC\\Automation project\\credentials.xlsx";
        try {
            FileInputStream file = new FileInputStream(new File(excelPath));
            Workbook workbook = new XSSFWorkbook(file);
            Sheet sheet = workbook.getSheetAt(0); // Read the first sheet

            // Read Username from 2nd row, 1st column (index 0)
            Row row = sheet.getRow(1); // 0-based indexing; 1 = second row
            username = row.getCell(0).getStringCellValue(); // First column
            password = row.getCell(1).getStringCellValue(); // Second column

            System.out.println("Username: " + username);
            System.out.println("Password: " + password);

            workbook.close();
            file.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void searchTextInFile(File file, String searchText) {
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean found = false;
            System.out.println("Searching for '" + searchText + "' in file...");
            while ((line = br.readLine()) != null) {
                if (line.contains(searchText)) {
                    System.out.println("Match found: " + line);  // print the whole matching line
                    found = true;
                }
            }
            if (!found) {
                System.out.println("Text '" + searchText + "' not found in the file.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void get_ip() throws IOException {
        browserDriver.get("http://cc.bitdriverupdater.com/productprice.svc/gtipinfo");
        WebElement ip_address = browserDriver.findElement(By.xpath("//pre"));
        String ipaddress = ip_address.getText();
        run.setText("IP address: " + "\n" + ipaddress);
        save_doc();
        save_current_page_scrrentshot();
        save_doc();
        JSONObject obj = new JSONObject(ipaddress);
        ip = obj.getJSONObject("result").getString("ip");
        modifiedIP = ip.replace(".", "_");
        System.out.println(modifiedIP);
    }

    public static void get_all_parms() throws IOException {
        BasicMethods basicMethods = PageFactory.initElements(browserDriver, BasicMethods.class);
        browserDriver.get("https://wgip.winriser.com/winrsr/" + modifiedIP + ".txt");
        System.out.println(" bro bro!");
        WebElement all_params = browserDriver.findElement(By.xpath("//pre"));
        save_current_Page_URL(browserDriver);
        String allparams = (all_params.getText());
        run.setText("All params: " + "\n" + allparams);
        save_doc();
        save_current_page_scrrentshot();
        save_doc();

    }

    public static void downloadConfirmation() throws InterruptedException, IOException {
        // 2. Wait until download completes
        File downloadedFile = new File(filePath);
        int waitSeconds = 120;
        while (waitSeconds > 0 && !downloadedFile.exists()) {
            Thread.sleep(1000);
            waitSeconds--;
        }
        if (!downloadedFile.exists()) {
            System.out.println("Download failed!");
            return;
        }
        System.out.println("File downloaded: " + downloadedFile.getAbsolutePath());
        //closeBrowser();
    }

    public static void Launch_winriser() throws InterruptedException {
        int maxRetries = 50;
        int retryCount = 0;
        boolean launched = false;
        while (retryCount < maxRetries) {
            try {
                DesiredCapabilities winCaps = new DesiredCapabilities();
                winCaps.setCapability("app", "C:/Program Files/Win Riser/winrgr.exe");
                appDriver = new WindowsDriver<>(new URL("http://127.0.0.1:4723"), winCaps);
                Thread.sleep(500);
                launched = true;
                break;
            } catch (Exception e) {
                retryCount++;
                if (retryCount < maxRetries) {
                    Thread.sleep(1000); // wait 10 seconds before retry
                }
            }
        }

        if (!launched) {
            throw new RuntimeException("Failed to launch WinRiser after " + maxRetries + " attempts.");
        }
    }

    public static void navigate_to_upgrade_to_pro() throws InterruptedException, MalformedURLException {
        System.out.println("chlo yha to aa rha h ");
        Launch_winriser();
        System.out.println("yha kahi aaya kya");
        appDriver.findElementByName("2").click();
        appDriver.findElementByName("Enter Activation Code").click();
        appDriver.findElementByName("Upgrade To PRO Now").click();
    }

    public static void navigate_back_winriser_activate() throws InterruptedException, MalformedURLException {
        // 8. Return to desktop app and enter activation_key
        DesiredCapabilities rootCaps = new DesiredCapabilities();
        rootCaps.setCapability("app", "Root");
        WindowsDriver<WindowsElement> rootDriver = new WindowsDriver<>(new URL("http://127.0.0.1:4723"), rootCaps);
        WindowsElement appWindow = rootDriver.findElementByName("Win Riser");
        String windowHandle = appWindow.getAttribute("NativeWindowHandle");
        int hwnd = Integer.parseInt(windowHandle);
        String hexHwnd = Integer.toHexString(hwnd);

        DesiredCapabilities attachedCaps = new DesiredCapabilities();
        attachedCaps.setCapability("appTopLevelWindow", hexHwnd);
        WindowsDriver<WindowsElement> attachedAppDriver = new WindowsDriver<>(new URL("http://127.0.0.1:4723"), attachedCaps);
        appDriver.findElementByName("2").click();
        appDriver.findElementByName("Enter Activation Code").click();
        Thread.sleep(3000);
        attachedAppDriver.findElementByClassName("TextBox").sendKeys(BasicMethods.licenseKey);
        Thread.sleep(2000);

        try {
            WebElement register_now = attachedAppDriver.findElement(By.name("Register Now"));
            if (register_now.isDisplayed()) {
                register_now.click();
            }
        } catch (NoSuchElementException e) {
            WebElement activate_now = attachedAppDriver.findElementByName("Activate Now");
            activate_now.click();
        }
        attachedAppDriver.quit();
        rootDriver.quit();
    }

    public static void killDebugChrome() throws IOException {
        Runtime.getRuntime().exec("taskkill /F /IM chrome.exe");
    }

    public static void installApplication() throws IOException, InterruptedException {
        System.out.println("yha aaya kya ");
        // 3. Start installer manually via Runtime
        Thread.sleep(6000);
        Process process = Runtime.getRuntime().exec(filePath);
        // 4. Attach to the installer window using 'Root'
        DesiredCapabilities rootCapabilities = new DesiredCapabilities();
        rootCapabilities.setCapability("app", "Root");
        WindowsDriver<WindowsElement> rootSession = new WindowsDriver<>(new URL("http://127.0.0.1:4723"), rootCapabilities);
        Thread.sleep(12000);
        System.out.println("yha kahi aaya kya");
        System.out.println(rootSession.getTitle());
        rootSession.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        // 5. Find the installer window (exact name via inspect.exe — update as per real title)
        WindowsElement installerWindow = rootSession.findElementByXPath("//*[contains(@Name, 'Setup - Win Riser')]");
        String windowHandle = installerWindow.getAttribute("NativeWindowHandle");
        int windowHandleInt = Integer.parseInt(windowHandle);
        String hexWindowHandle = Integer.toHexString(windowHandleInt);
        Thread.sleep(1000);
        System.out.println("to fir yha kyo nahi aaya");
        System.out.println(rootSession.getTitle());
        // 6. Reattach to the real installer window
        DesiredCapabilities appCapabilities = new DesiredCapabilities();
        appCapabilities.setCapability("appTopLevelWindow", hexWindowHandle);
        WindowsDriver<WindowsElement> installerSession = new WindowsDriver<>(new URL("http://127.0.0.1:4723"), appCapabilities);
        installerSession.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        // 7. Perform installation steps: Next > Install > Finish
        System.out.println("ana to usko yha bhi chaaye tha ");
        Thread.sleep(1000);

        // ✅ FIX: Set global static driver before using it
        BasicMethods.appDriver = installerSession;
        installerSession.findElementByName(" Scan system after installation is complete.").click();
        installerSession.findElementByName("Next").click();
        System.out.println(" ab to bat had se bad gai");
        Thread.sleep(15000);
        System.out.println("Application installed successfully.");
        Thread.sleep(1000);
        waitAndAttachToDebugChrome();

    }

    public static void unInstallWinRiser() throws InterruptedException {
        Thread.sleep(6000);
        try {
            String appKey = "{70C25EA6-B217-4EDA-9F0C-46C581DE2C53}_is1";
            String uninstallRegPath = "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall";
            String fullRegPath = uninstallRegPath + "\\" + appKey;
            // Query the UninstallString
            String command = "reg query \"" + fullRegPath + "\" /v UninstallString";
            ProcessBuilder pb = new ProcessBuilder("cmd", "/c", command);
            Process process = pb.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            String uninstallString = null;
            while ((line = reader.readLine()) != null) {
                if (line.contains("UninstallString")) {
                    String[] parts = line.trim().split("    ");
                    if (parts.length >= 3) {
                        uninstallString = parts[parts.length - 1].trim();
                        break;
                    }
                }
            }
            reader.close();

            if (uninstallString != null) {
                ProcessBuilder uninstallPb = new ProcessBuilder("cmd", "/c", uninstallString + " /SILENT");
                uninstallPb.inheritIO(); // Show output
                Process uninstallProcess = uninstallPb.start();
                uninstallProcess.waitFor();
                System.out.println("Uninstall command executed.");
            } else {
                System.out.println("Uninstall command not found.");
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void getInstallTracking(String[] args) {
        // 1. Get today's date in the required format
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String dateString = today.format(formatter);

        // 2. Build the filename dynamically
        String fileName = "PrePrice" + dateString + ".txt.txt";

        // 3. Get user's Downloads folder path
        String userHome = System.getProperty("user.home");
        String downloadsPath = userHome + "\\Downloads\\" + fileName;

        // 4. Read a file and search for text
        File file = new File(downloadsPath);
        if (file.exists()) {
            System.out.println("File found: " + downloadsPath);
            searchTextInFile(file, "38.51.130.28");
        } else {
            System.out.println("File not found: " + downloadsPath);
        }
    }

    public static void waitAndAttachToDebugChrome() {
        if (browserDriver != null) {
            System.out.println("WebDriver already attached.");
            return;
        }

        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.setExperimentalOption("debuggerAddress", "127.0.0.1:9222");

        int retries = 10;
        while (retries-- > 0) {
            try {
                browserDriver = new ChromeDriver(options);
                System.out.println("Attached to debug Chrome.");
                return;
            } catch (Exception e) {
                System.out.println("Waiting for Chrome to be available on 9222...");
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ie) {
                    ie.printStackTrace();
                }
            }
        }

        System.err.println("Failed to attach to Chrome after multiple attempts.");
    }

    public static void reconnectAndPrintURL() {
        try {
            // Check if debug Chrome is alive
            try (Socket socket = new Socket("localhost", 9222)) {
                // Proceed if connected
                ChromeOptions options = new ChromeOptions();
                options.setExperimentalOption("debuggerAddress", "localhost:9222");
                browserDriver = new ChromeDriver(options);

                if (browserDriver != null) {
                    String currentUrl = browserDriver.getCurrentUrl();
                    System.out.println("Current URL: " + currentUrl);
                } else {
                    System.out.println("Failed to connect: browserDriver is null.");
                }
            } catch (IOException e) {
                System.out.println("Debug Chrome is not running on port 9222.");
            }

        } catch (Exception e) {
            System.err.println("Error during reconnect or URL fetch:");
            e.printStackTrace();
        }
    }

    public static void afterInstallPageURL() throws InterruptedException {
        //attachToDebugChrome();
        Set<String> windowHandles = browserDriver.getWindowHandles();
        List<String> tabs = new ArrayList<>(windowHandles);
        browserDriver.switchTo().window(tabs.get(tabs.size() - 1));
        browserDriver.getCurrentUrl();
        save_current_Page_URL(browserDriver);
        save_current_page_scrrentshot();
        Thread.sleep(6000);
    }

    public static void afterUninstallPageURL() throws InterruptedException {
        Thread.sleep(9000);
        Set<String> windowHandles = browserDriver.getWindowHandles();
        List<String> tabs = new ArrayList<>(windowHandles);
        browserDriver.switchTo().window(tabs.get(tabs.size() - 1));
        browserDriver.getCurrentUrl();
        save_current_Page_URL(browserDriver);
        save_current_page_scrrentshot();
    }


    public static void tryAgain(WebElement web) throws InterruptedException {
        boolean clicked = false;
        int retries = 0;
        int maxRetries = 15;

        while (!clicked && retries < maxRetries) {
            try {
                web.click();
                clicked = true;
            } catch (Exception e) {
                retries++;
                System.out.println("Retry " + retries + " failed: " + e.getMessage());
                Thread.sleep(6000);
            }
        }
        if (!clicked) {
            throw new RuntimeException("Failed to click on element '2' after " + maxRetries + " retries.");
        }
    }
}



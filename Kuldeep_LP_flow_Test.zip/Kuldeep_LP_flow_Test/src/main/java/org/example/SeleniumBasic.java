package org.example;

import io.appium.java_client.windows.WindowsDriver;
import io.appium.java_client.windows.WindowsElement;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.time.Duration;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import static org.bouncycastle.oer.its.ieee1609dot2.basetypes.Duration.seconds;

public class SeleniumBasic extends BasicMethods {

    public static void switchNewTab() throws InterruptedException {
        String parentWindow = browserDriver.getWindowHandle();
        Set<String> allWindows = browserDriver.getWindowHandles();
        for (String window : allWindows) {
            if (!window.equals(parentWindow)) {
                browserDriver.switchTo().window(window);
                break;
            }
        }
    }

    public static void switchBackMainTab() {
        String parentWindow = browserDriver.getWindowHandle();
        Set<String> allWindows = browserDriver.getWindowHandles();
        for (String window : allWindows) {
            if (!window.equals(parentWindow)) {
                browserDriver.switchTo().window(window);
                break;
            }
        }
        browserDriver.switchTo().window(parentWindow);
    }
    public static void selectDropDown() {
        //get list of elements
        List<WebElement> allElement = browserDriver.findElements(By.tagName("a"));
        // Find the dropdown element
        WebElement dropdownElement = browserDriver.findElement(By.id("dropdown-id"));
        // Create a Select object
        Select dropdown = new Select(dropdownElement);
        // Get all options from dropdown
        List<WebElement> allOptions = dropdown.getOptions();
        // Loop through and select each option
        for (int i = 0; i < allOptions.size(); i++) {
            dropdown.selectByIndex(i);
            // Print selected option text
            System.out.println("Selected: " + dropdown.getFirstSelectedOption().getText());
        }

        browserDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }
}

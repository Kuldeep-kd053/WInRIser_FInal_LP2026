package org.example;


import org.openqa.selenium.*;

import java.io.IOException;
import java.util.Scanner;

import static org.example.WinAppDriverLauncher.launchWinAppDriver;


public class Main extends BasicMethods {


    public static void main(String[] args) {
        try {
            System.out.println("Automation started!");
            downloadInstallWinRiser();
            UpgradeToPROActivateWinRiser();
            unInstallWinRiserProcess();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void downloadInstallWinRiser() throws Exception {
        launchWinAppDriver();
        launchBrowserIfNeeded();
        browserDriver.get(LP_URL);
        save_current_Page_URL(BasicMethods.browserDriver);
        save_current_page_scrrentshot();
        clickOnDownloadButton();
        get_ip();
        get_all_parms();
        downloadConfirmation();
        installApplication();
        afterInstallPageURL();
    }

    public static void UpgradeToPROActivateWinRiser() throws Exception {
        navigate_to_upgrade_to_pro();
        BasicMethods.checkout_details();
        BasicMethods.cross_sale();
        fetch_licenseKey();
        navigate_back_winriser_activate();
        BasicMethods.save_doc();
    }

    public static void unInstallWinRiserProcess() throws IOException, InterruptedException {
        unInstallWinRiser();
        afterUninstallPageURL();
        BasicMethods.closeDocument();
        closeBrowser();
    }



//
//        public static void main(String[] args) {
//
//            Scanner sc = new Scanner(System.in);
//
//            System.out.print("Enter name: ");
//            String name = sc.nextLine();
//
//            System.out.print("Enter age: ");
//            int age = sc.nextInt();
//
//            System.out.println("Name: " + name);
//            System.out.println("Age: " + age);
//
//            sc.close();
//        }


}

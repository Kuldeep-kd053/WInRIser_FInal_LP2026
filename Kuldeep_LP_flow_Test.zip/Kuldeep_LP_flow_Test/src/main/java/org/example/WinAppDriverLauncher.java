package org.example;

import java.io.*;
import java.net.Socket;


public class WinAppDriverLauncher {

    public static Process launchWinAppDriver() throws IOException {
        String winAppDriverPath = "C:\\Program Files\\Windows Application Driver\\WinAppDriver.exe";
        ProcessBuilder pb = new ProcessBuilder("powershell.exe", "-NoProfile", "-Command",
                "Start-Process -Verb RunAs -FilePath '" + winAppDriverPath + "'");
        pb.inheritIO(); // to see output in console
        Process process = pb.start();
        System.out.println("WinAppDriver launch command executed.");
        return process;
    }

    public static boolean isWinAppDriverRunning() {
        try (Socket socket = new Socket("127.0.0.1", 4723)) {
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public static void main(String[] args) {
        try {
            launchWinAppDriver();
            Thread.sleep(5000); // Wait 5 seconds for WinAppDriver to launch
            if (isWinAppDriverRunning()) {
                System.out.println("WinAppDriver is running!");
            } else {
                System.out.println("WinAppDriver did NOT start properly.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

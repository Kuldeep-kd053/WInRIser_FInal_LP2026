package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class IntelDriverList {
    public WebDriver driver;

    @FindBy(how = How.XPATH, using = "//span[@class='coveo-pager-next-icon']")
    public WebElement next_page;

    @FindBy(how = How.XPATH, using = "//a[contains(text(),'View Details')]")
    public List<WebElement> view_details_button_number;

    @FindBy(how = How.XPATH, using = "//a[contains(text(),'Download')]")
    public WebElement download_button;

    public static int sub_total;
    public static int s_total;

    @Test
    public void intel_drivers_download() throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();

        driver.get("https://www.intel.com/content/www/us/en/search.html#sort=%40lastmodifieddt%20descending");
        //driver.get("https://www.intel.com/content/www/us/en/search.html#first=790&sort=%40lastmodifieddt%20descending&f:@tabfilter=[Downloads]");

        Thread.sleep(6000);
        try {
            driver.findElement(By.xpath("//span[contains(text(),'Drivers & Software')]")).click();
            WebDriverWait wait = new WebDriverWait(driver, 15);
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='content-wrap']")));
        } catch (Exception e) {
            IntelDriverList page = PageFactory.initElements(driver, IntelDriverList.class);
            Thread.sleep(2000);
            for (int i = 0; i < 10; i++) {
                ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 500);");
                Thread.sleep(500);
            }
            page.next_page.click();

        }
        boolean hasNext = true;
        while (hasNext) {
            // Reinitialize the page to avoid stale elements
            IntelDriverList page = PageFactory.initElements(driver, IntelDriverList.class);
            page.driver = this.driver;
            // Wait until all view details are visible
            try {
                WebDriverWait wait = new WebDriverWait(driver, 15);
                wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//a[contains(text(),'View Details')]")));
                System.out.println("Found View Details buttons: " + page.view_details_button_number.size());
            } catch (Exception e) {
                for (int i = 0; i < 10; i++) {
                    ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 500);");
                    Thread.sleep(500);
                }
                page.next_page.click();
            }

            for (int i = 0; i < page.view_details_button_number.size(); i++) {
                try {
                    // Re-locate page object again before clicking due to navigation
                    page = PageFactory.initElements(driver, IntelDriverList.class);
                    WebElement viewButton = page.view_details_button_number.get(i);
                    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", viewButton);
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", viewButton);
                    Thread.sleep(2000);
                    get_driver_URL_from_download_button(driver);
                    get_urls(driver);
                    driver.navigate().back();
                    WebDriverWait wait = new WebDriverWait(driver, 15);
                    wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='content-wrap']")));
                } catch (Exception e) {
                    System.out.println("Error clicking view details at index " + i + ": " + e.getMessage());
                    driver.navigate().back();
                }
            }

            // Now try clicking Next if it exists and is not disabled
            try {
                page = PageFactory.initElements(driver, IntelDriverList.class);
                WebElement next = page.next_page;

                if (next != null && next.isDisplayed()) {
                    String className = next.getAttribute("class");
                    if (className != null && className.contains("disabled")) {
                        System.out.println("Next button is disabled. Ending pagination.");
                        hasNext = false;
                    } else {
                        for (int i = 0; i < 10; i++) {
                            ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, 500);");
                            Thread.sleep(500);
                        }
                        next.click();
                        Thread.sleep(3000);
                    }
                } else {
                    System.out.println("Next button not found. Ending pagination.");
                    hasNext = false;
                }
            } catch (Exception e) {
                System.out.println("Pagination ended: " + e.getMessage());
                hasNext = false;
            }
        }
        writeLinksToExcel("driverURLs.xlsx");
    }

    public static void get_driver_URL_from_download_button(WebDriver driver) {
        List<WebElement> links = driver.findElements(By.xpath("//a[contains(text(),'Download')]"));
        for (WebElement link : links) {
            String url = link.getAttribute("href");
            if (url != null && (url.startsWith("http") || url.startsWith("https"))) {
                verifyLink(url);
            }
        }
        sub_total = links.size();
    }

    public static void get_urls(WebDriver driver) {
        List<WebElement> links1 = driver.findElements(By.xpath("//button[@data-wap_ref='download-button']"));
        for (WebElement link1 : links1) {
            String url1 = link1.getAttribute("data-href");
            if (url1 != null && (url1.startsWith("http") || url1.startsWith("https"))) {
                verifyLink(url1);
            }
        }
        s_total = links1.size();
    }

    private static final List<String> validLinks = new ArrayList<>();

    public static void verifyLink(String urlLink) {
        try {
            URL url = new URL(urlLink);
            HttpURLConnection httpConn = (HttpURLConnection) url.openConnection();
            httpConn.setRequestMethod("HEAD");
            httpConn.connect();
            int responseCode = httpConn.getResponseCode();
            if (responseCode >= 200 && responseCode < 300) {
                System.out.println("Valid: " + urlLink);
                validLinks.add(urlLink);
            }
        } catch (IOException ignored) {
        }
    }

    public static void writeLinksToExcel(String fileNameOnly) {
        // Get user's desktop path and define target folder
        String userHome = System.getProperty("user.home");
        String folderPath = userHome + File.separator + "Desktop" + File.separator + "IntelURLReports";

        // Create the folder if it doesn't exist
        File folder = new File(folderPath);
        if (!folder.exists()) {
            boolean created = folder.mkdirs();
            if (created) {
                System.out.println("Created folder: " + folderPath);
            } else {
                System.out.println("❌ Failed to create folder: " + folderPath);
                return;
            }
        }

        // Full Excel file path
        String filePath = folderPath + File.separator + fileNameOnly;

        // Write valid URLs to Excel
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Valid URLs");

        for (int i = 0; i < validLinks.size(); i++) {
            Row row = sheet.createRow(i);
            Cell cell = row.createCell(0);
            cell.setCellValue(validLinks.get(i));
        }

        try (FileOutputStream fileOut = new FileOutputStream(filePath)) {
            workbook.write(fileOut);
            workbook.close();
            System.out.println("✅ Excel saved at: " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
